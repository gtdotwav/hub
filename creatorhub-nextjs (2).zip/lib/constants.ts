export const POINTS_TO_BRL_RATE = 100 // 100 Pontos = R$ 1,00
export const PLATFORM_FEE_RATE = 0.18 // 18%
