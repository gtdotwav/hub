// Example, expand as needed
export interface GameScene {
  gameTitle: string
  sceneImageUrl: string
  description: string
}
