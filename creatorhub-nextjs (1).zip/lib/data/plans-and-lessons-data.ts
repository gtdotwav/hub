export interface PlanOrAula {
  id: string
  title: string
  type: "Plano" | "Aula Gratuita" | "E-book"
  price?: string
  description: string
  detailedDescription: string
  features?: string[]
  learningObjectives?: string[]
  duration?: string
  href?: string
  ctaPopupText: string
  imageUrl?: string
  pdfUrl?: string
  pdfName?: string
}

export const plansAndLessonsData: PlanOrAula[] = [
  {
    id: "plano-basico",
    title: "Plano Básico",
    type: "Plano",
    price: "R$ 29,90/mês",
    description: "Ideal para criadores iniciantes que querem começar a monetizar seu conteúdo.",
    detailedDescription:
      "O Plano Básico oferece todas as ferramentas essenciais para você começar sua jornada como criador de conteúdo profissional.",
    features: [
      "Até 50 tarefas por mês",
      "Acesso a templates básicos",
      "Suporte por email",
      "Dashboard básico de analytics",
      "Comunidade de criadores",
    ],
    ctaPopupText: "Começar com Básico",
    href: "/planos/basico",
  },
  {
    id: "plano-pro",
    title: "Plano Pro",
    type: "Plano",
    price: "R$ 99,90/mês",
    description: "Para criadores profissionais que querem acelerar seu crescimento com IA.",
    detailedDescription:
      "O Plano Pro inclui todas as funcionalidades do Básico, além de recursos avançados de IA para acelerar sua criação de conteúdo.",
    features: [
      "**Tarefas ilimitadas**",
      "**IA para criação de conteúdo**",
      "Templates premium exclusivos",
      "Analytics avançados",
      "Suporte prioritário 24/7",
      "Sessões de mentoria mensais",
    ],
    ctaPopupText: "Upgrade para Pro",
    href: "/planos/pro",
  },
  {
    id: "plano-premium",
    title: "Plano Premium",
    type: "Plano",
    price: "R$ 199,90/mês",
    description: "O plano mais completo para criadores que querem maximizar seus resultados.",
    detailedDescription:
      "O Plano Premium oferece todos os recursos Pro, além de funcionalidades exclusivas para criadores de alto nível.",
    features: [
      "Tudo do Plano Pro",
      "**IA avançada personalizada**",
      "Templates exclusivos premium",
      "Consultoria individual mensal",
      "Acesso antecipado a novos recursos",
      "Suporte dedicado",
    ],
    ctaPopupText: "Escolher Premium",
    href: "/planos/premium",
  },
]
