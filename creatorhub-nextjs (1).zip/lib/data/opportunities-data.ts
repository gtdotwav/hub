export interface Opportunity {
  id: string
  title: string
  type: string
  bonus: string
  detailedDescription: string
  taskType: "generic-form" | "image-carousel" | "tweet-ideas" | "game-scenes" | "vegan-ideas"
  aiEnabled: boolean
}

export const opportunitiesData: Opportunity[] = [
  {
    id: "produtividade-video-titles",
    title: "5 Títulos para Vídeos de Produtividade",
    type: "Brainstorming Criativo",
    bonus: "+ 15 Pontos",
    detailedDescription: "Crie 5 títulos chamativos para vídeos sobre produtividade pessoal e profissional.",
    taskType: "generic-form",
    aiEnabled: true,
  },
  {
    id: "resumir-artigo-tech",
    title: "Resumir Artigo de Tecnologia",
    type: "Síntese de Conteúdo",
    bonus: "+ 20 Pontos",
    detailedDescription: "Leia e resuma um artigo sobre tecnologia em até 200 palavras.",
    taskType: "generic-form",
    aiEnabled: true,
  },
  {
    id: "roteiro-video-financas",
    title: "Roteiro: Vídeo sobre Finanças Pessoais",
    type: "Roteirização",
    bonus: "+ 25 Pontos",
    detailedDescription: "Desenvolva um roteiro completo para um vídeo de 5 minutos sobre educação financeira.",
    taskType: "generic-form",
    aiEnabled: true,
  },
  {
    id: "carousel-instagram-food",
    title: "Carousel Instagram: Receitas Saudáveis",
    type: "Criatividade Interativa",
    bonus: "+ 30 Pontos",
    detailedDescription: "Crie um carousel de 5 slides para Instagram com receitas saudáveis e rápidas.",
    taskType: "image-carousel",
    aiEnabled: false,
  },
  {
    id: "tweet-ideas-ai-news",
    title: "10 Ideias de Tweets sobre IA",
    type: "Redação para Redes Sociais",
    bonus: "+ 18 Pontos",
    detailedDescription: "Desenvolva 10 ideias criativas de tweets sobre inteligência artificial e tecnologia.",
    taskType: "tweet-ideas",
    aiEnabled: false,
  },
  {
    id: "game-scenes-tour",
    title: "Tour Virtual: Cenários de Jogos",
    type: "Demonstração Interativa",
    bonus: "+ 35 Pontos",
    detailedDescription: "Crie descrições detalhadas para um tour virtual por 3 cenários diferentes de jogos.",
    taskType: "game-scenes",
    aiEnabled: false,
  },
]
