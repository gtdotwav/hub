"use client"
import { createContext, useContext, useState, type ReactNode } from "react"

interface ProPopupContextType {
  isOpen: boolean
  selectedPlan: string | null
  billingCycle: "monthly" | "quarterly" | "semiannual"
  openProPopup: (planId: string, cycle?: "monthly" | "quarterly" | "semiannual") => void
  closeProPopup: () => void
}

const ProPopupContext = createContext<ProPopupContextType | undefined>(undefined)

export function ProPopupProvider({ children }: { children: ReactNode }) {
  const [isOpen, setIsOpen] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null)
  const [billingCycle, setBillingCycle] = useState<"monthly" | "quarterly" | "semiannual">("monthly")

  const openProPopup = (planId: string, cycle: "monthly" | "quarterly" | "semiannual" = "monthly") => {
    setSelectedPlan(planId)
    setBillingCycle(cycle)
    setIsOpen(true)
  }

  const closeProPopup = () => {
    setIsOpen(false)
    setSelectedPlan(null)
  }

  return (
    <ProPopupContext.Provider value={{ isOpen, selectedPlan, billingCycle, openProPopup, closeProPopup }}>
      {children}
    </ProPopupContext.Provider>
  )
}

export function useProPopup() {
  const context = useContext(ProPopupContext)
  if (context === undefined) {
    throw new Error("useProPopup must be used within a ProPopupProvider")
  }
  return context
}
