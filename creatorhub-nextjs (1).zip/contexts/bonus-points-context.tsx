"use client"
import { createContext, useContext, useState, type ReactNode } from "react"

interface BonusPointsContextType {
  bonusPoints: number
  addBonusPoints: (points: number) => void
  resetBonusPoints: () => void
}

const BonusPointsContext = createContext<BonusPointsContextType | undefined>(undefined)

export function BonusPointsProvider({ children }: { children: ReactNode }) {
  const [bonusPoints, setBonusPoints] = useState(0)

  const addBonusPoints = (points: number) => {
    setBonusPoints((prev) => prev + points)
  }

  const resetBonusPoints = () => {
    setBonusPoints(0)
  }

  return (
    <BonusPointsContext.Provider value={{ bonusPoints, addBonusPoints, resetBonusPoints }}>
      {children}
    </BonusPointsContext.Provider>
  )
}

export function useBonusPoints() {
  const context = useContext(BonusPointsContext)
  if (context === undefined) {
    throw new Error("useBonusPoints must be used within a BonusPointsProvider")
  }
  return context
}
