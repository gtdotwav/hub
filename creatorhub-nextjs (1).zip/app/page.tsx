"use client"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useState } from "react"
import { cn } from "@/lib/utils"
import { useBonusPoints } from "@/contexts/bonus-points-context"
import { useProPopup } from "@/contexts/pro-popup-context"
import { opportunitiesData, type Opportunity } from "@/lib/data/opportunities-data"
import { plansAndLessonsData } from "@/lib/data/plans-and-lessons-data"
import { TaskRenderer } from "@/components/tasks/task-renderer"
import {
  Zap,
  TrendingUp,
  ShieldCheck,
  Users,
  Star,
  RocketIcon,
  CheckCircle,
  BookOpen,
  Sparkles,
  Lightbulb,
  Twitter,
  FileText,
  Video,
  Gamepad2,
  HelpCircle,
  ImageIcon,
  MessageSquare,
  Film,
  Crown,
  DollarSign,
  DownloadCloud,
  Cpu,
} from "lucide-react"

function HeroSection() {
  const { bonusPoints, addBonusPoints } = useBonusPoints()
  const { openProPopup } = useProPopup()
  const [opportunities] = useState<Opportunity[]>(opportunitiesData)
  const [selectedOpportunity, setSelectedOpportunity] = useState<Opportunity | null>(null)
  const [submittedTasks, setSubmittedTasks] = useState<string[]>([])
  const [taskComment, setTaskComment] = useState("")
  const [taskRating, setTaskRating] = useState(0)

  const handleTaskSubmit = (taskId: string, bonusString: string, _formData: Record<string, any>) => {
    setSubmittedTasks((prev) => [...prev, taskId])
    const pointsMatch = bonusString.match(/\+ (\d+) Pontos/)
    if (pointsMatch && pointsMatch[1]) {
      const pointsEarned = Number.parseInt(pointsMatch[1], 10)
      addBonusPoints(pointsEarned)
    }
  }

  const handleOpportunityClick = (opportunity: Opportunity) => {
    if (submittedTasks.length >= 2 && !submittedTasks.includes(opportunity.id)) {
      openProPopup("plano-pro")
    } else {
      setSelectedOpportunity(opportunity)
      setTaskComment("")
      setTaskRating(0)
    }
  }

  const getOpportunityIcon = (type: string) => {
    if (type.toLowerCase().includes("brainstorming")) return <Lightbulb className="w-4 h-4 text-primary/80 mr-1.5" />
    if (type.toLowerCase().includes("redação")) return <Twitter className="w-4 h-4 text-primary/80 mr-1.5" />
    if (type.toLowerCase().includes("criatividade")) return <Sparkles className="w-4 h-4 text-primary/80 mr-1.5" />
    if (type.toLowerCase().includes("síntese")) return <FileText className="w-4 h-4 text-primary/80 mr-1.5" />
    if (type.toLowerCase().includes("roteirização")) return <Video className="w-4 h-4 text-primary/80 mr-1.5" />
    return <Zap className="w-4 h-4 text-primary/80 mr-1.5" />
  }

  const GetMainOpportunityIcon = ({ opportunity }: { opportunity: Opportunity }) => {
    let IconComponent = HelpCircle
    let iconColor = "text-gray-500/70"
    
    switch (opportunity.taskType) {
      case "image-carousel":
        IconComponent = ImageIcon
        iconColor = "text-pink-500/70"
        break
      case "tweet-ideas":
        IconComponent = MessageSquare
        iconColor = "text-blue-500/70"
        break
      case "game-scenes":
        IconComponent = Gamepad2
        iconColor = "text-purple-500/70"
        break
      case "generic-form":
        if (opportunity.title.toLowerCase().includes("produtividade")) {
          IconComponent = TrendingUp
          iconColor = "text-orange-500/70"
        } else if (opportunity.title.toLowerCase().includes("resumir")) {
          IconComponent = FileText
          iconColor = "text-yellow-600/70"
        } else if (opportunity.title.toLowerCase().includes("roteiro")) {
          IconComponent = Film
          iconColor = "text-red-500/70"
        } else {
          IconComponent = Lightbulb
          iconColor = "text-yellow-500/70"
        }
        break
    }
    
    return <IconComponent size={56} className={`${iconColor} mb-3 group-hover:scale-110 transition-transform duration-300`} />
  }

  const handleDownload = (pdfUrl: string, fileName: string) => {
    const anchor = document.createElement("a")
    anchor.href = pdfUrl
    anchor.setAttribute("download", fileName)
    document.body.appendChild(anchor)
    anchor.click()
    document.body.removeChild(anchor)
  }

  return (
    <section className="relative pt-32 pb-20 md:pt-40 md:pb-24 overflow-hidden">
      <div className="absolute inset-0 -z-10 bg-grid-pattern bg-center [mask-image:linear-gradient(to_bottom,white,transparent,transparent)] dark:[mask-image:linear-gradient(to_bottom,black,transparent,transparent)]"></div>
      
      <div className="container mx-auto px-4 md:px-6">
        {/* Hero Content */}
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-6 animate-pulse">
            <Zap className="w-4 h-4" />
            <span>Junte-se à revolução dos criadores</span>
            <TrendingUp className="w-4 h-4 text-green-500" />
          </div>

          <h1 className="text-4xl md:text-7xl font-bold font-heading tracking-tighter mb-6">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary via-blue-500 to-purple-600">
              Transforme Seu Conteúdo em
            </span>
            <br />
            <span className="relative">
              Renda Recorrente
              <div className="absolute -bottom-2 left-0 right-0 h-1 bg-gradient-to-r from-primary to-purple-600 rounded-full"></div>
            </span>
          </h1>

          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto mb-8 leading-relaxed">
            A plataforma que já ajudou mais de <span className="font-bold text-primary">12.000 criadores</span> a
            faturar mais de <span className="font-bold text-green-400">R$ 2.5 milhões</span> com conteúdo exclusivo.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
            <Button asChild size="lg" className="btn-primary w-full sm:w-auto group relative overflow-hidden">
              <Link href="/#tarefas-hub">
                <div className="absolute inset-0 bg-gradient-to-r from-primary to-green-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <RocketIcon className="w-5 h-5 mr-2 relative z-10" />
                <span className="relative z-10">Começar a ganhar com tarefas</span>
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="w-full sm:w-auto group">
              <Link href="/como-funciona">
                <HelpCircle className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" />
                Como Funciona
              </Link>
            </Button>
          </div>

          {/* Stats */}
          <div className="flex justify-center items-center gap-x-8 gap-y-4 flex-wrap mb-12">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <ShieldCheck className="w-5 h-5 text-green-500 animate-pulse" />
              <span>Pagamentos 100% seguros</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Users className="w-5 h-5 text-primary" />
              <span>+12.847 criadores ativos</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
              <span>4.9/5 avaliação média</span>
            </div>
          </div>

          {/* Avatar Stack */}
          <div className="flex justify-center -space-x-3 mb-16">
            {["A", "B", "C", "D"].map((letter, i) => (
              <div
                key={letter}
                className={`w-12 h-12 rounded-full border-2 border-background flex items-center justify-center text-white font-bold hover:scale-110 transition-transform cursor-pointer bg-gradient-to-r ${
                  i === 0 ? "from-blue-500 to-purple-600" :
                  i === 1 ? "from-green-500 to-blue-500" :
                  i === 2 ? "from-purple-500 to-pink-500" :
                  "from-orange-500 to-red-500"
                }`}
              >
                {letter}
              </div>
            ))}
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 border-2 border-background text-primary font-bold text-sm hover:scale-110 transition-transform cursor-pointer">
              +12k
            </div>
          </div>
        </div>

        {/* Bonus Points Display */}
        <div className="text-center my-8 p-4 bg-muted/50 rounded-lg">
          <p className="text-lg">
            Pontos de Bônus Acumulados: <span className="font-bold text-amber-500 text-xl">{bonusPoints} Pts</span>
          </p>
        </div>

        {/* Tasks Hub */}
        <div id="tarefas-hub" className="max-w-7xl mx-auto text-center mb-24 scroll-mt-24">
          <h2 className="text-3xl md:text-4xl font-bold font-heading mb-4">Tarefas Rápidas do Hub</h2>
          <p className="text-lg text-muted-foreground mb-12 max-w-2xl mx-auto">
            Complete tarefas simples, ganhe pontos e explore o poder da IA (Plano Pro) para agilizar suas criações.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {opportunities.map((item) => (
              <div
                key={item.id}
                className="group relative flex flex-col rounded-xl overflow-hidden shadow-lg transition-all duration-300 hover:scale-[1.02] hover:shadow-primary/20 cursor-pointer bg-card border border-border hover:border-primary/30"
                onClick={() => handleOpportunityClick(item)}
                role="button"
                tabIndex={0}
              >
                <div className="absolute top-3 right-3 bg-green-500 text-white text-xs font-bold px-2.5 py-1 rounded-full z-10 shadow">
                  {item.bonus}
                </div>

                <div className="flex-grow flex flex-col items-center justify-center p-8 text-center min-h-[180px]">
                  <GetMainOpportunityIcon opportunity={item} />
                </div>

                <div className="p-5 border-t border-border/80 bg-muted/30">
                  <span className="text-xs font-semibold uppercase tracking-wider text-primary flex items-center mb-1.5">
                    {getOpportunityIcon(item.type)}
                    {item.type}
                  </span>
                  <h3 className="text-md md:text-lg font-semibold font-heading leading-tight text-foreground mb-2">
                    {item.title}
                  </h3>
                  <p className="text-xs text-muted-foreground">Clique para ver detalhes e participar.</p>
                </div>
              </div>
            ))}
          </div>

          {/* Task Dialog */}
          {selectedOpportunity && (
            <Dialog open={!!selectedOpportunity} onOpenChange={(isOpen) => !isOpen && setSelectedOpportunity(null)}>
              <DialogContent className="sm:max-w-lg bg-card text-card-foreground flex flex-col max-h-[90vh]">
                <DialogHeader>
                  <DialogTitle className="text-2xl font-heading text-primary flex items-center">
                    {getOpportunityIcon(selectedOpportunity.type)}
                    {selectedOpportunity.title}
                  </DialogTitle>
                  <div className="flex justify-between items-center mt-2">
                    <Badge variant="outline" className="text-xs">{selectedOpportunity.type}</Badge>
                    <span className="text-lg font-bold text-green-500">{selectedOpportunity.bonus}</span>
                  </div>
                </DialogHeader>

                <div className="flex-grow overflow-y-auto py-4">
                  <DialogDescription className="text-sm text-muted-foreground whitespace-pre-line">
                    {selectedOpportunity.detailedDescription}
                  </DialogDescription>

                  <div className="my-4 py-4 border-y border-border space-y-3">
                    <div>
                      <label className="text-sm font-medium text-foreground text-left block mb-1.5">
                        Avalie esta tarefa:
                      </label>
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Button
                            key={star}
                            variant="ghost"
                            size="icon"
                            onClick={() => setTaskRating(star)}
                            className="p-1 h-auto w-auto"
                          >
                            <Star className={cn("w-5 h-5", star <= taskRating ? "text-yellow-400 fill-yellow-400" : "text-gray-300")} />
                          </Button>
                        ))}
                      </div>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-foreground text-left block mb-1.5">
                        Seu comentário:
                      </label>
                      <Textarea
                        value={taskComment}
                        onChange={(e) => setTaskComment(e.target.value)}
                        rows={3}
                        className="text-sm"
                        placeholder="Deixe seu feedback..."
                      />
                    </div>
                  </div>

                  <div className="mt-6 pt-6 border-t border-border">
                    {submittedTasks.includes(selectedOpportunity.id) ? (
                      <div className="text-center p-4 bg-green-500/10 rounded-md">
                        <CheckCircle className="w-10 h-10 text-green-500 mx-auto mb-2" />
                        <h4 className="font-semibold text-lg text-green-600">Bônus Recebido!</h4>
                        <p className="text-sm text-muted-foreground">Seus pontos foram adicionados.</p>
                      </div>
                    ) : (
                      <TaskRenderer task={selectedOpportunity} onSubmit={handleTaskSubmit} />
                    )}
                  </div>

                  {selectedOpportunity.aiEnabled && !submittedTasks.includes(selectedOpportunity.id) && (
                    <>
                      <div className="relative text-center mt-4">
                        <div className="absolute inset-0 flex items-center">
                          <span className="w-full border-t border-border"></span>
                        </div>
                        <div className="relative flex justify-center text-xs uppercase">
                          <span className="bg-card px-2 text-muted-foreground">OU</span>
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        className="w-full h-auto p-4 mt-4 rounded-lg border-primary/30 hover:border-primary/50 bg-gradient-to-br from-purple-500/10 via-primary/10 to-blue-500/10 hover:shadow-lg transition-all group"
                        onClick={() => {
                          setSelectedOpportunity(null)
                          setTimeout(() => openProPopup("plano-pro"), 150)
                        }}
                      >
                        <div className="flex flex-col items-center text-center">
                          <Sparkles className="w-8 h-8 text-primary mb-2 transition-transform group-hover:scale-125" />
                          <h3 className="font-bold text-lg text-primary">Resolver com IA</h3>
                          <p className="text-xs text-muted-foreground mt-1">
                            Economize tempo. Deixe nossa IA criar uma solução. (Exclusivo PRO)
                          </p>
                        </div>
                      </Button>
                    </>
                  )}
                </div>

                <DialogFooter>
                  <DialogClose asChild>
                    <Button type="button" variant="outline">Fechar</Button>
                  </DialogClose>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}
        </div>

        {/* E-books Section */}
        <div className="max-w-7xl mx-auto text-center mt-24 mb-24">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-6">
              <BookOpen className="w-4 h-4" />
              <span>E-books gratuitos para criadores</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold font-heading mb-4">Biblioteca de E-books Exclusivos</h2>
            <p className="text-lg text-muted-foreground mb-12 max-w-2xl mx-auto">
              Baixe nossos e-books gratuitos e aprenda técnicas avançadas para turbinar sua criação de conteúdo
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {/* E-book 1: IA Guide */}
            <Card className="group relative overflow-hidden border-2 border-sky-200 hover:border-sky-300 transition-all duration-300 hover:scale-[1.02] hover:shadow-lg">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-sky-500 to-sky-600"></div>
              <div className="absolute top-4 right-4">
                <Badge className="bg-sky-500 text-white text-xs">Gratuito</Badge>
              </div>
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-sky-500/10 flex items-center justify-center">
                  <Cpu className="w-8 h-8 text-sky-500" />
                </div>
                <CardTitle className="text-xl font-heading">Guia Completo de IA para Criadores</CardTitle>
                <p className="text-sm text-muted-foreground mt-2">
                  Aprenda a usar inteligência artificial para acelerar sua criação de conteúdo
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-3 text-foreground">O que você vai aprender:</h4>
                  <ul className="space-y-2">
                    {[
                      "Ferramentas de IA essenciais para criadores",
                      "Prompts eficazes para diferentes tipos de conteúdo",
                      "Automação de tarefas repetitivas",
                      "Casos práticos e exemplos reais"
                    ].map((item, index) => (
                      <li key={index} className="flex items-start">
                        <Cpu className="w-4 h-4 text-sky-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <FileText className="w-4 h-4" />
                  <span>45 páginas • PDF</span>
                </div>
              </CardContent>
              <CardFooter>
                <Button
                  className="w-full bg-sky-600 hover:bg-sky-700"
                  onClick={() => handleDownload("/assets/ebooks/guia-ia-criadores.pdf", "Guia-Completo-IA-para-Criadores.pdf")}
                >
                  <DownloadCloud className="w-4 h-4 mr-2" />
                  Baixar E-book
                </Button>
              </CardFooter>
            </Card>

            {/* E-book 2: Psychology & Copywriting */}
            <Card className="group relative overflow-hidden border-2 border-teal-200 hover:border-teal-300 transition-all duration-300 hover:scale-[1.02] hover:shadow-lg">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-teal-500 to-teal-600"></div>
              <div className="absolute top-4 right-4">
                <Badge className="bg-teal-500 text-white text-xs">Gratuito</Badge>
              </div>
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-teal-500/10 flex items-center justify-center">
                  <Lightbulb className="w-8 h-8 text-teal-500" />
                </div>
                <CardTitle className="text-xl font-heading">Psicologia de Copy e Roteirização</CardTitle>
                <p className="text-sm text-muted-foreground mt-2">
                  Domine as técnicas psicológicas por trás de textos persuasivos
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-3 text-foreground">O que você vai aprender:</h4>
                  <ul className="space-y-2">
                    {[
                      "Gatilhos mentais e persuasão",
                      "Estruturas de roteiro que convertem",
                      "Storytelling para engajamento",
                      "Análise de campanhas de sucesso"
                    ].map((item, index) => (
                      <li key={index} className="flex items-start">
                        <Lightbulb className="w-4 h-4 text-teal-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <FileText className="w-4 h-4" />
                  <span>62 páginas • PDF</span>
                </div>
              </CardContent>
              <CardFooter>
                <Button
                  className="w-full bg-teal-600 hover:bg-teal-700"
                  onClick={() => handleDownload("/psychology-copywriting-course.png", "Psicologia-Copywriting-Roteirizacao.pdf")}
                >
                  <DownloadCloud className="w-4 h-4 mr-2" />
                  Baixar E-book
                </Button>
              </CardFooter>
            </Card>

            {/* E-book 3: Content Monetization */}
            <Card className="group relative overflow-hidden border-2 border-green-200 hover:border-green-300 transition-all duration-300 hover:scale-[1.02] hover:shadow-lg">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-green-500 to-green-600"></div>
              <div className="absolute top-4 right-4">
                <Badge className="bg-green-500 text-white text-xs">Gratuito</Badge>
              </div>
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-green-500/10 flex items-center justify-center">
                  <DollarSign className="w-8 h-8 text-green-500" />
                </div>
                <CardTitle className="text-xl font-heading">Monetizando Seu Conteúdo</CardTitle>
                <p className="text-sm text-muted-foreground mt-2">
                  Estratégias comprovadas para transformar conteúdo em renda
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-3 text-foreground">O que você vai aprender:</h4>
                  <ul className="space-y-2">
                    {[
                      "Modelos de monetização digital",
                      "Criação de produtos digitais",
                      "Estratégias de precificação",
                      "Funis de vendas eficazes"
                    ].map((item, index) => (
                      <li key={index} className="flex items-start">
                        <DollarSign className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <FileText className="w-4 h-4" />
                  <span>38 páginas • PDF</span>
                </div>
              </CardContent>
              <CardFooter>
                <Button
                  className="w-full bg-green-600 hover:bg-green-700"
                  onClick={() => handleDownload("/ebook-kirvano.pdf", "Monetizando-Conteudo-Kirvano.pdf")}
                >
                  <DownloadCloud className="w-4 h-4 mr-2" />
                  Baixar E-book
                </Button>
              </CardFooter>
            </Card>
          </div>

          {/* Bottom CTA for E-books */}
          <div className="mt-12 text-center p-8 bg-gradient-to-r from-sky-500/10 to-green-500/10 rounded-xl border border-sky-200">
            <h4 className="text-xl font-bold font-heading mb-3">Quer acesso a ainda mais conteúdo exclusivo?</h4>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Nossos planos Pro e Premium incluem e-books avançados, templates exclusivos e muito mais conteúdo para acelerar seu crescimento.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="outline" asChild>
                <Link href="/biblioteca">
                  <BookOpen className="w-4 h-4 mr-2" />
                  Ver Biblioteca Completa
                </Link>
              </Button>
              <Button onClick={() => openProPopup("plano-pro")}>
                <Crown className="w-4 h-4 mr-2" />
                Upgrade para Pro
              </Button>
            </div>
          </div>
        </div>

        {/* Plans Section */}
        <div className="max-w-7xl mx-auto text-center mt-24">
          <h2 className="text-3xl md:text-4xl font-bold font-heading mb-4">Explore Nossos Planos</h2>
          <p className="text-lg text-muted-foreground mb-12 max-w-2xl mx-auto">Escolha o plano ideal para acelerar seu crescimento.</p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {plansAndLessonsData.filter(plan => plan.type === "Plano").map((plan) => (
              <Card key={plan.id} className={cn(
                "relative overflow-hidden border-2 transition-all duration-300 hover:scale-[1.02] hover:shadow-lg",
