import type React from "react"
import type { Metadata } from "next"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { BonusPointsProvider } from "@/contexts/bonus-points-context"
import { AuthProvider } from "@/contexts/auth-context"
import { ProPopupProvider } from "@/contexts/pro-popup-context"
import Header from "@/components/layout/header"
import Footer from "@/components/layout/footer"

export const metadata: Metadata = {
  title: "CreatorHub - Transforme Conteúdo em Renda",
  description: "A plataforma para criadores de conteúdo monetizarem sua paixão.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <body>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem disableTransitionOnChange>
          <BonusPointsProvider>
            <AuthProvider>
              <ProPopupProvider>
                <Header />
                <main>{children}</main>
                <Footer />
              </ProPopupProvider>
            </AuthProvider>
          </BonusPointsProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
