"use client"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, Crown, Users, Sparkles, RocketIcon } from "lucide-react"
import { useProPopup } from "@/contexts/pro-popup-context"
import { plansAndLessonsData } from "@/lib/data/plans-and-lessons-data"

export function ProPopup() {
  const { isOpen, selectedPlan, billingCycle, closeProPopup } = useProPopup()

  const plans = plansAndLessonsData.filter((item) => item.type === "Plano")
  const currentPlan = plans.find((plan) => plan.id === selectedPlan)

  const formatPrice = (price: string) => {
    const priceMatch = price.match(/R\$ (\d+,\d+)\/mês/)
    if (priceMatch && priceMatch[1]) {
      const monthlyPriceValue = Number.parseFloat(priceMatch[1].replace(",", "."))
      if (billingCycle === "quarterly") {
        const quarterlyPrice = (monthlyPriceValue * 3 * 0.9).toFixed(2).replace(".", ",")
        return `R$ ${quarterlyPrice}/trimestre`
      }
      if (billingCycle === "semiannual") {
        const semiannualPrice = (monthlyPriceValue * 6 * 0.8).toFixed(2).replace(".", ",")
        return `R$ ${semiannualPrice}/semestre`
      }
      return `R$ ${monthlyPriceValue.toFixed(2).replace(".", ",")}/mês`
    }
    return price
  }

  const getPlanIcon = (planId: string) => {
    switch (planId) {
      case "plano-basico":
        return <Users className="w-8 h-8 text-blue-500" />
      case "plano-pro":
        return <RocketIcon className="w-8 h-8 text-purple-500" />
      case "plano-premium":
        return <Crown className="w-8 h-8 text-amber-500" />
      default:
        return <Users className="w-8 h-8 text-blue-500" />
    }
  }

  if (!currentPlan) return null

  return (
    <Dialog open={isOpen} onOpenChange={closeProPopup}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader className="text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-primary to-purple-600">
            {getPlanIcon(currentPlan.id)}
          </div>
          <DialogTitle className="text-2xl font-heading">Upgrade para {currentPlan.title}</DialogTitle>
        </DialogHeader>

        <Card className="border-2 border-primary/20">
          <CardHeader className="text-center">
            <div className="flex justify-between items-center">
              <CardTitle className="text-xl">{currentPlan.title}</CardTitle>
              {currentPlan.id === "plano-pro" && <Badge className="bg-purple-500 text-white">Mais Popular</Badge>}
            </div>
            <div className="text-3xl font-bold text-primary mt-2">
              {currentPlan.price ? formatPrice(currentPlan.price) : "Gratuito"}
            </div>
          </CardHeader>

          <CardContent>
            <p className="text-muted-foreground mb-4">{currentPlan.description}</p>

            {currentPlan.features && (
              <div>
                <h4 className="font-semibold mb-3">Recursos inclusos:</h4>
                <ul className="space-y-2">
                  {currentPlan.features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      {feature.toLowerCase().includes("ia") ? (
                        <Sparkles className="w-4 h-4 text-purple-500 mr-2 mt-0.5 flex-shrink-0" />
                      ) : (
                        <CheckCircle className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      )}
                      <span
                        className="text-sm"
                        dangerouslySetInnerHTML={{
                          __html: feature.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>"),
                        }}
                      />
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>

          <CardFooter>
            <Button className="w-full" size="lg">
              {currentPlan.ctaPopupText}
            </Button>
          </CardFooter>
        </Card>

        <DialogFooter>
          <Button variant="outline" onClick={closeProPopup}>
            Talvez mais tarde
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
