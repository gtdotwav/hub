"use client"

import Link from "next/link"
import { Rocket, Menu, Sun, Moon, Wallet, Gift } from "lucide-react"
import { useState, useEffect } from "react"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { useBonusPoints } from "@/contexts/bonus-points-context"
import { useAuth } from "@/contexts/auth-context"

const navLinks = [
  { href: "/beneficios", label: "Benefícios" },
  { href: "/como-funciona", label: "Como Funciona" },
  { href: "/calculadora", label: "Ganhos" },
  { href: "/depoimentos", label: "Depoimentos" },
  { href: "/faq", label: "FAQ" },
]

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const { theme, setTheme } = useTheme()
  const { bonusPoints } = useBonusPoints()
  const { user } = useAuth()

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)
  }

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        isScrolled ? "bg-card/80 backdrop-blur-lg border-b border-border shadow-md h-16" : "bg-transparent h-[72px]",
      )}
    >
      <div
        className={cn(
          "container mx-auto flex items-center justify-between gap-6 px-4 md:px-6",
          isScrolled ? "h-16" : "h-[72px]",
        )}
      >
        <Link href="/" className="flex items-center gap-2">
          <Rocket className="h-7 w-7 md:h-8 md:w-8 text-primary" />
          <span className="text-xl md:text-2xl font-bold font-heading">CreatorHub</span>
        </Link>

        <nav className="hidden md:flex items-center gap-6">
          {navLinks.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2 md:gap-4">
          {user && (
            <Link
              href="/carteira"
              className="flex items-center gap-1.5 text-xs font-medium text-primary rounded-full px-2 py-1 border border-primary/30 hover:bg-primary/10 transition-colors md:px-3 md:py-1.5"
            >
              <Wallet className="h-4 w-4" />
              <span className="hidden sm:inline">Saldo:</span>
              <span className="font-bold text-foreground">{formatCurrency(user.balance?.real ?? 0)}</span>
            </Link>
          )}

          <div className="flex items-center gap-1.5 text-xs font-medium text-amber-500 rounded-full px-2 py-1 border border-amber-500/30 md:px-3 md:py-1.5">
            <Gift className="h-4 w-4" />
            <span className="font-bold">{bonusPoints} Pts</span>
          </div>

          <Button variant="ghost" size="icon" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
            {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>

          {!user && (
            <div className="hidden md:flex items-center gap-2">
              <Button asChild variant="ghost">
                <Link href="/login">Entrar</Link>
              </Button>
              <Button asChild className="btn-primary">
                <Link href="/register">Criar Conta</Link>
              </Button>
            </div>
          )}

          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            <Menu className="h-6 w-6" />
          </Button>
        </div>
      </div>
    </header>
  )
}
