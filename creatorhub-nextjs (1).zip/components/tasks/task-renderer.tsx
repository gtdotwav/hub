"use client"
import { Button } from "@/components/ui/button"
import type React from "react"

import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { useState } from "react"
import type { Opportunity } from "@/lib/data/opportunities-data"

interface TaskRendererProps {
  task: Opportunity
  onSubmit: (taskId: string, bonusString: string, formData: Record<string, any>) => void
}

export function TaskRenderer({ task, onSubmit }: TaskRendererProps) {
  const [formData, setFormData] = useState<Record<string, any>>({})

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(task.id, task.bonus, formData)
  }

  const handleInputChange = (key: string, value: string) => {
    setFormData((prev) => ({ ...prev, [key]: value }))
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {task.taskType === "generic-form" && (
        <>
          <div>
            <label className="text-sm font-medium mb-2 block">Sua resposta:</label>
            <Textarea
              placeholder="Digite sua resposta aqui..."
              value={formData.response || ""}
              onChange={(e) => handleInputChange("response", e.target.value)}
              rows={4}
              required
            />
          </div>
        </>
      )}

      {task.taskType === "tweet-ideas" && (
        <>
          {[1, 2, 3].map((num) => (
            <div key={num}>
              <label className="text-sm font-medium mb-2 block">Ideia {num}:</label>
              <Input
                placeholder={`Tweet ${num}...`}
                value={formData[`tweet${num}`] || ""}
                onChange={(e) => handleInputChange(`tweet${num}`, e.target.value)}
                required
              />
            </div>
          ))}
        </>
      )}

      {task.taskType === "image-carousel" && (
        <>
          {[1, 2, 3].map((num) => (
            <div key={num}>
              <label className="text-sm font-medium mb-2 block">Slide {num}:</label>
              <Textarea
                placeholder={`Conteúdo do slide ${num}...`}
                value={formData[`slide${num}`] || ""}
                onChange={(e) => handleInputChange(`slide${num}`, e.target.value)}
                rows={2}
                required
              />
            </div>
          ))}
        </>
      )}

      <Button type="submit" className="w-full">
        Enviar e Ganhar {task.bonus}
      </Button>
    </form>
  )
}
